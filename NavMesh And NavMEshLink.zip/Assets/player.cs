
using UnityEngine;
using UnityEngine.AI;

public class player : MonoBehaviour
{
    public Camera cam;
    public NavMeshAgent agent;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            //Debug.Log("Clicked");

            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            //Debug.Log(ray);

            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
               // Debug.Log("hit");
                agent.SetDestination(hit.point);
            }
        }
    }
}
