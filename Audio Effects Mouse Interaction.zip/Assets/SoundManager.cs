using UnityEngine.Audio;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static AudioClip jumpsound, walksound;
    static AudioSource audiosrc;

    // Start is called before the first frame update
    void Start()
    {
        jumpsound = Resources.Load<AudioClip>("jump");
        walksound = Resources.Load<AudioClip>("walk");
        audiosrc = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {

    }

    public static void playsound(string clip)
    {
        switch (clip)
        {
            case "jump":
                audiosrc.PlayOneShot(jumpsound);
                break;
            case "walk":
                audiosrc.PlayOneShot(walksound);
                break;
        }
    }
}
